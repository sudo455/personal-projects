#include <string>
using namespace std;

string* split(string s, int n, char separator);

// s το string που θέλουμε να χωρίσουμε, n ο αριθμός των τμημάτων στα οποία θα χωρίσουμε το s 
// και separator ο χαρακτήρας στον οποίο θα χωρίζεται το κάθε τμήμα του s π.χ. ','
